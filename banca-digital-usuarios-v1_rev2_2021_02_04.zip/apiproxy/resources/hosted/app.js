var ApiMocker = require('apimocker');

console.log('apimocker.js application starting...');

var options = {};

var apiMocker = ApiMocker.createServer(options)
    .setConfigFile('config-generated.json')
    .start();